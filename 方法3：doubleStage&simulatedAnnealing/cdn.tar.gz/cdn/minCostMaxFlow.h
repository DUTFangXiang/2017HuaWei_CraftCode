#ifndef __MINCOSTMAXFLOW_H__
#define __MINCOSTMAXFLOW_H__

#include<set>
#include"graph.h"



long minCostMaxFlow(SparseGraph &gh, set<int> &server);

#endif
